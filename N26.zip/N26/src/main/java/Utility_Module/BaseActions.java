package Utility_Module;

public class BaseActions {


    public BaseActions(){

        init();
    }

    public void init(){

    }
}
