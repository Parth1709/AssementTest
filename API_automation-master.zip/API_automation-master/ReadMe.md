Steps to execute : mvn clean test -Dtest=Test_PetEndPoints

./src/main : project java classes

./src/test/java : project test classes

./src/test/resources : project test resources

./src/main/java/Utility_Module : project helper classes

./src/main/java/API_Module : api related pojos and helper classes

